export const contractApi = {};
